<?php
// Incluir el archivo de conexión
include_once('conexion.php');

// Función para obtener todos los alumnos
function obtenerAlumnos()
{
    $conexion = conexion(); // Obtener la conexión a la base de datos

    // Consulta SQL para obtener todos los alumnos
    $query = "SELECT id_alumno, nombre, apellido FROM alumno";
    $result = $conexion->query($query);

    $alumnos = array();

    // Recorrer el resultado y almacenar los alumnos en un array
    while ($row = $result->fetch_assoc()) {
        $alumnos[] = $row;
    }

    // Cerrar la conexión y retornar los alumnos
    $conexion->close();
    return $alumnos;
}

// Función para obtener todas las carreras
function obtenerCarreras()
{
    $conexion = conexion(); // Obtener la conexión a la base de datos

    // Consulta SQL para obtener todas las carreras
    $query = "SELECT id_carrera, carrera FROM carrera";
    $result = $conexion->query($query);

    $carreras = array();

    // Recorrer el resultado y almacenar las carreras en un array
    while ($row = $result->fetch_assoc()) {
        $carreras[] = $row;
    }

    // Cerrar la conexión y retornar las carreras
    $conexion->close();
    return $carreras;
}

// Función para realizar la inscripción del alumno
function inscribirAlumno($idAlumno, $idCarrera)
{
    $conexion = conexion(); // Obtener la conexión a la base de datos

    // Preparar la consulta SQL para insertar la inscripción
    $query = "INSERT INTO inscripcion (id_alumno, id_carrera) VALUES (?, ?)";
    $stmt = $conexion->prepare($query);

    // Verificar si la preparación de la consulta fue exitosa
    if ($stmt) {
        // Asociar los parámetros y ejecutar la consulta
        $stmt->bind_param("ii", $idAlumno, $idCarrera);
        $stmt->execute();

        // Verificar si se realizó la inserción correctamente
        if ($stmt->affected_rows > 0) {
            return true; // Inserción exitosa
        } else {
            return false; // No se pudo insertar
        }
    } else {
        return false; // Error en la preparación de la consulta
    }

    // Cerrar la declaración y la conexión
    $stmt->close();
    $conexion->close();
}
?>
